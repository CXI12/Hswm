import os
import pkg_resources

def calc_container(path):
    total_size = 0
    for dirpath, dirnames, filenames in os.walk(path):
        for f in filenames:
            fp = os.path.join(dirpath, f)
            total_size += os.path.getsize(fp)
    return total_size/(1024**2)


sizes = [(d,calc_container(os.path.join(d.location, d.project_name))) for d in pkg_resources.working_set]
print(*sorted(sizes,key=lambda x:x[1],reverse=True),sum([i[1] for i in sizes]),sep="\n")